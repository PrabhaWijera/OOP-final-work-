package lk.ijse.dep.service;

import java.util.Random;

public class AiPlayer extends Player {
    public AiPlayer(Board newBoard) {
        super(newBoard);
    }

    @Override
    public void movePiece(int col) {
        int randAI=col;//Genarating random numbers
        do {

            Random input = new Random();
            randAI=input.nextInt(6);

            }while (!board.isLegalMove(randAI));
        if (board.isLegalMove(randAI)){
            board.updateMove(randAI,Piece.GREEN);
            board.getBoardUI().update(randAI,false);

            Winner winner=board.findWinner();
            Piece winningpiece  = winner.getWinningPiece();


            if (winningpiece==Piece.GREEN){
                board.getBoardUI();
            }
        }
    }
}