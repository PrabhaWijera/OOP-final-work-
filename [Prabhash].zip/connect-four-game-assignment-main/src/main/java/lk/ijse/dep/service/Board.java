package lk.ijse.dep.service;

public interface Board<piece> {
    int NUM_OF_ROWS=5;
    int NUM_OF_COLS=6;

     BoardUI getBoardUI();
     int findNextAvailableSpot(int col);
     boolean existLegalMoves(int col);
     void updateMove(int col,Piece move);

    void updateMove(int col, int row, Piece move);

    public Winner findWinner();

    boolean existLegalMoves();

    boolean isLegalMove(int col);
}