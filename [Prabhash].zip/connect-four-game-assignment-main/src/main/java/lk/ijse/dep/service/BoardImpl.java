package lk.ijse.dep.service;

import java.awt.desktop.SystemSleepEvent;

public class BoardImpl implements Board {
    Piece[][] pieces;
    BoardUI boardUI;

    public BoardImpl(BoardUI boardUI) {
        this.boardUI = boardUI;
        pieces = new Piece[NUM_OF_COLS][NUM_OF_ROWS];
        setArrayValues();

    }

    public void setArrayValues() {
        for (int i = 0; i < NUM_OF_COLS; i++) {
            for (int j = 0; j < NUM_OF_ROWS; j++) {
                pieces[i][j] = Piece.EMPTY;
            }
        }

    }

    @Override
    public BoardUI getBoardUI() {
        return boardUI;
    }

    @Override
    public int findNextAvailableSpot(int col) {
        for (int i = 0; i < NUM_OF_COLS; i++) {
            if (pieces[col][i] == (Piece.EMPTY)) {
                return i;
            }
        }
        return -1;
    }

    @Override
    public boolean existLegalMoves(int col) {
        for (int i = 0; i < NUM_OF_COLS; i++) {
            for (int j = 0; j < NUM_OF_ROWS; j++) {
                if (pieces[i][j] == (Piece.EMPTY)) {
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    public boolean isLegalMove(int col) {

        return findNextAvailableSpot(col) != -1;

    }

    @Override
    public boolean existLegalMoves() {
        for (int i = 0; i < NUM_OF_COLS; i++) {
            for (int j = 0; j < NUM_OF_ROWS; j++) {
                if (pieces[i][j] == (Piece.EMPTY)) {
                    return false;
                }
            }
        }
        return true;
    }

    @Override
    public void updateMove(int col, Piece move) {
        if (!existLegalMoves()) {
            return;
        }
        if (isLegalMove(col)) {
            int RowNum = findNextAvailableSpot(col);
            pieces[col][RowNum] = move;
        }

    }


    @Override
    public void updateMove(int col, int row, Piece move) {
        pieces[col][row] = move;
        boardUI.update(col, !move.equals(Piece.GREEN));
    }

    @Override
    public Winner findWinner() {
       /* for (int i = 0; i < NUM_OF_COLS; i++) {

            int GreenCount = 0;
            int BlueCount = 0;
            int EmptyCount = 0;
            for (int j = 0; j < NUM_OF_ROWS; j++) {
                if (pieces[i][j] == Piece.GREEN) {
                    System.out.println("Green");
                    GreenCount += 1;
                    BlueCount = 0;
                    EmptyCount = 0;
                }
                if (pieces[i][j] == Piece.BLUE) {
                    System.out.println("Blue");
                    GreenCount = 0;
                    BlueCount += 1;
                    EmptyCount = 0;
                }
                if (pieces[i][j] == Piece.EMPTY) {

                    GreenCount = 0;
                    BlueCount = 0;
                    EmptyCount += 1;
                }
                if (GreenCount == 4 ) {
                    System.out.println("Greencount");
                    Piece winningpiece =  Piece.GREEN ;

                    return new Winner(winningpiece, i, i, j, j);
                }
                if (BlueCount == 4 ) {
                    System.out.println("Blue");
                    Piece winningpiece =  Piece.BLUE ;

                    return new Winner(winningpiece, i, i, j, j);
                }

            }
        }
        for (int i=0;i<NUM_OF_ROWS;i++){
            int GreenCount=0;
            int BlueCount=0;
            int EmptyCount=0;
            for (int j=0;j<NUM_OF_COLS;j++){
                if (pieces[j][i]==Piece.GREEN){
                    System.out.println("Green");
                    GreenCount+=1;
                    BlueCount=0;
                    EmptyCount=0;
                }
                if (pieces[j][i]==Piece.BLUE){
                    System.out.println("blue");
                    GreenCount=0;
                    BlueCount+=1;
                    EmptyCount=0;
                }
                if (pieces[j][i]==Piece.EMPTY){
                    System.out.println("2Empty");
                    GreenCount=0;
                    BlueCount=0;
                    EmptyCount+=1;

                }
                if (GreenCount==4){
                    System.out.println("Green count");
                    Piece winningpiece=Piece.GREEN;
                    return new Winner(winningpiece,j,j,i,i);
                }
                if (BlueCount==4){
                    System.out.println("BlueCount");
                    Piece winningpiece=Piece.BLUE;
                    return new Winner(winningpiece,j,j,i,i);
                }
            }
        }
                return null;*/


        return null;
    }
}
