package lk.ijse.dep.service;


public class HumanPlayer extends Player {
    public HumanPlayer(Board newBoard) {
        super(newBoard);
    }
    @Override
        public void movePiece(int col){
             if (board.isLegalMove(col)){//Checking legle moves
                 board.updateMove(col,Piece.BLUE);
                 board.getBoardUI().update(col,true);

                 Winner winner=board.findWinner();
                 Piece winningpiece= winner.getWinningPiece();





                 if (winningpiece==Piece.BLUE){
                     board.getBoardUI().notifyWinner(winner);
                 }else if (!board.existLegalMoves()){//if there o winner ---
                     board.getBoardUI().notifyWinner(new Winner(Piece.EMPTY));
                 }
             }
        }
    }

